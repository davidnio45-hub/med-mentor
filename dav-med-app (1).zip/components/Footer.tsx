import React from 'react';
import { findPageById } from '../constants';
import type { Page } from '../types';

interface FooterProps {
    setActivePage: (page: Page) => void;
}

export const Footer: React.FC<FooterProps> = ({ setActivePage }) => {
    
    const handleNav = (pageId: string) => {
        const page = findPageById(pageId);
        if (page) {
            setActivePage(page);
        }
    }

    return (
        <footer className="bg-white border-t p-4 text-center text-sm text-slate-500">
            <p>
                <button onClick={() => handleNav('privacy')} className="hover:underline mx-2">Privacy</button>
                |
                <button onClick={() => handleNav('copyright')} className="hover:underline mx-2">Copyright</button>
            </p>
            <p className="mt-1">All content © David Niyonzima. Unauthorized use or distribution is prohibited.</p>
        </footer>
    );
}